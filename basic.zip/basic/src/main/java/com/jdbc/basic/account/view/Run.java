package com.jdbc.basic.account.view;

import com.jdbc.basic.score.view.ScoreMenu;

public class Run {
    public static void main(String[] args) {

        new AccountMenu().mainMenu();

    }
}
