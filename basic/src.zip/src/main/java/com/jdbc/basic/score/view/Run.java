package com.jdbc.basic.score.view;

public class Run {
    public static void main(String[] args) {

        new ScoreMenu().mainMenu();

    }
}
