package com.example.examplecore;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ExamplecoreApplication {

	public static void main(String[] args) {
		SpringApplication.run(ExamplecoreApplication.class, args);
	}

}
